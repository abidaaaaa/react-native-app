/**
 * Piezas reutilizables del diseño glass.
 * Si cambias algo aquí (o en constants/design.ts), cambia en toda la app.
 */

import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleProp,
  StyleSheet,
  Text,
  View,
  ViewStyle,
} from 'react-native';
import { G, R, S, glass } from '../constants/design';

/* ---------- Mancha de color suave (círculos concéntricos) ---------- */
function Blob({ size, color, style }: { size: number; color: string; style: ViewStyle }) {
  const layers = [1, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1];
  return (
    <View
      pointerEvents="none"
      style={[{ position: 'absolute', width: size, height: size }, style]}>
      {layers.map(k => {
        const d = size * k;
        return (
          <View
            key={k}
            style={{
              position: 'absolute',
              width: d,
              height: d,
              borderRadius: d / 2,
              left: (size - d) / 2,
              top: (size - d) / 2,
              backgroundColor: color,
              opacity: 0.06,
            }}
          />
        );
      })}
    </View>
  );
}

/* ---------- Fondo con manchas de color (va detrás de todo) ---------- */
export function GlassBackground({
  children,
  style,
}: {
  children?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <View style={[styles.root, style]}>
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <Blob size={420} color={G.blob.lavender} style={{ top: -140, left: -150 }} />
        <Blob size={340} color={G.blob.sky} style={{ top: '28%', right: -170 }} />
        <Blob size={380} color={G.blob.rose} style={{ bottom: -150, left: -110 }} />
        <Blob size={220} color={G.blob.mint} style={{ bottom: '18%', right: -60 }} />
      </View>
      {children}
    </View>
  );
}

/* ---------- Tarjeta de vidrio ---------- */
export function GlassCard({
  children,
  style,
  strong = false,
}: {
  children?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  strong?: boolean;
}) {
  return <View style={[glass.card, strong && styles.cardStrong, style]}>{children}</View>;
}

/* ---------- Botón ---------- */
type Variant = 'primary' | 'secondary' | 'danger';

interface GlassButtonProps {
  title: string;
  onPress?: () => void;
  variant?: Variant;
  disabled?: boolean;
  loading?: boolean;
  style?: StyleProp<ViewStyle>;
  accessibilityLabel?: string;
}

export function GlassButton({
  title,
  onPress,
  variant = 'primary',
  disabled = false,
  loading = false,
  style,
  accessibilityLabel,
}: GlassButtonProps) {
  const isDisabled = disabled || loading;
  const textColor =
    variant === 'primary' ? G.onAccent : variant === 'danger' ? G.danger : G.accent;

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel ?? title}
      accessibilityState={{ disabled: isDisabled }}
      style={({ pressed }) => [
        styles.button,
        variant === 'primary' && styles.primary,
        variant === 'secondary' && styles.secondary,
        variant === 'danger' && styles.danger,
        pressed && styles.pressed,
        isDisabled && styles.disabled,
        style,
      ]}>
      {loading ? (
        <ActivityIndicator color={textColor} />
      ) : (
        <Text style={[styles.buttonText, { color: textColor }]}>{title}</Text>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: G.bg,
    overflow: 'hidden',
  },
  cardStrong: {
    backgroundColor: G.glassStrong,
  },
  button: {
    minHeight: 50,
    borderRadius: R.pill,
    paddingHorizontal: S.xl,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  primary: {
    backgroundColor: G.accent,
    borderColor: 'rgba(255,255,255,0.45)',
    experimental_backgroundImage: `linear-gradient(135deg, ${G.accent}, ${G.accentEnd})`,
  },
  secondary: {
    backgroundColor: G.glassStrong,
    borderColor: G.border,
  },
  danger: {
    backgroundColor: G.dangerSoft,
    borderColor: G.border,
  },
  pressed: { opacity: 0.85, transform: [{ scale: 0.98 }] },
  disabled: { opacity: 0.5 },
  buttonText: { fontSize: 15, fontWeight: '700', letterSpacing: 0.2 },
});
