/**
 * SISTEMA DE DISEÑO (glass / cristal translúcido)
 * -----------------------------------------------
 * Este es el ÚNICO archivo que necesitas editar para cambiar el aspecto
 * de toda la app: colores, esquinas, espacios, tipografía y presets.
 *
 *  G  → colores            R → radios (esquinas)
 *  S  → espacios           T → textos
 *  glass → presets listos (tarjeta, input, chip)
 */

import { Platform, TextStyle, ViewStyle } from 'react-native';

/* ============ COLORES ============ */
export const G = {
  // Fondo base (detrás de las manchas de color)
  bg: '#F3ECFF',

  // Vidrio: blanco con transparencia
  glass: 'rgba(255,255,255,0.55)',
  glassStrong: 'rgba(255,255,255,0.72)',
  glassSoft: 'rgba(255,255,255,0.35)',

  // Bordes de luz del vidrio
  border: 'rgba(255,255,255,0.9)',
  borderSoft: 'rgba(255,255,255,0.6)',
  divider: 'rgba(109,85,184,0.14)',

  // Textos (todos con contraste mínimo 4.5:1 sobre el vidrio)
  text: '#3B2F5C',
  textSoft: '#5E4F85',
  textMute: '#675987',
  onAccent: '#FFFFFF',

  // Acento principal
  accent: '#6D55B8',
  accentEnd: '#9A5FB8',
  accentSoft: 'rgba(109,85,184,0.14)',

  // Estados
  danger: '#A8305F',
  dangerSoft: 'rgba(255,184,209,0.5)',
  success: '#2B735A',
  successSoft: 'rgba(168,235,204,0.55)',

  // Manchas de color del fondo
  blob: {
    lavender: '#C9B5FF',
    rose: '#FFB8D1',
    sky: '#A8D4FF',
    mint: '#A8EBCC',
    peach: '#FFCCA8',
  },
} as const;

/** Tonos para avatares (se elige uno según el id del estudiante) */
export const AVATAR_TONES = [
  'rgba(201,181,255,0.75)',
  'rgba(255,184,209,0.75)',
  'rgba(168,235,204,0.75)',
  'rgba(255,229,133,0.75)',
  'rgba(255,204,168,0.75)',
  'rgba(168,212,255,0.75)',
] as const;

/* ============ MEDIDAS ============ */
export const S = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 } as const;
export const R = { sm: 12, md: 18, lg: 24, xl: 28, pill: 999 } as const;

/* ============ TEXTOS ============ */
type TextKey = 'title' | 'heading' | 'body' | 'label' | 'caption';

export const T: Record<TextKey, TextStyle> = {
  title: { fontSize: 28, lineHeight: 34, fontWeight: '800', color: G.text, letterSpacing: -0.3 },
  heading: { fontSize: 18, lineHeight: 24, fontWeight: '700', color: G.text },
  body: { fontSize: 15, lineHeight: 22, fontWeight: '500', color: G.text },
  label: { fontSize: 12, lineHeight: 16, fontWeight: '700', color: G.textSoft, letterSpacing: 0.6 },
  caption: { fontSize: 13, lineHeight: 18, fontWeight: '500', color: G.textMute },
};

/* ============ EFECTOS ============ */
// En web se agrega desenfoque real del fondo; en móvil se ignora sin romper nada.
const webBlur: object =
  Platform.OS === 'web' ? { backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' } : {};

const SOFT_SHADOW = '0px 10px 30px rgba(109,85,184,0.16)';

/* ============ PRESETS ============ */
export const glass = {
  /** Tarjeta de vidrio */
  card: {
    backgroundColor: G.glass,
    borderWidth: 1,
    borderColor: G.border,
    borderRadius: R.xl,
    overflow: 'hidden',
    boxShadow: SOFT_SHADOW,
    ...webBlur,
  } as ViewStyle,

  /** Campo de texto */
  input: {
    backgroundColor: G.glassStrong,
    borderWidth: 1,
    borderColor: G.border,
    borderRadius: R.md,
    paddingHorizontal: S.lg,
    paddingVertical: 14,
    color: G.text,
    fontSize: 15,
  } as TextStyle,

  /** Campo con error */
  inputError: {
    borderColor: G.danger,
    backgroundColor: G.dangerSoft,
  } as TextStyle,

  /** Etiqueta pequeña tipo píldora */
  chip: {
    alignSelf: 'flex-start',
    backgroundColor: G.accentSoft,
    borderRadius: R.pill,
    paddingHorizontal: S.md,
    paddingVertical: 5,
  } as ViewStyle,
};

/** Opciones de encabezado para las pantallas de expo-router */
export const headerOptions = {
  headerStyle: { backgroundColor: G.bg },
  headerTitleStyle: { fontWeight: '800' as const, color: G.text },
  headerTintColor: G.text,
  headerShadowVisible: false,
  headerTitleAlign: 'left' as const,
};
